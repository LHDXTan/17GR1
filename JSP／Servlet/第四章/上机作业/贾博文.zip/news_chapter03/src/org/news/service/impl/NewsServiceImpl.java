package org.news.service.impl;



import org.news.dao.BaseDao;
import org.news.dao.impl.NewsDaoImpl;
import org.news.service.NewsService;

public class NewsServiceImpl extends BaseDao implements NewsService{

	@Override
	public String delPanDuan(int id) {
		NewsDaoImpl n=new NewsDaoImpl();
		int delNewId = n.delNewId(id);
		String yu="";
		if(delNewId==1){
			yu="ɾ���ɹ�";
			return yu;
		}else{
			yu="ɾ��ʧ��";	
		}
		return yu;
		
	}

	@Override
	public int upPanDuan(int id,Object []ob) {
		NewsDaoImpl n=new NewsDaoImpl();
		int count = n.updateNews(id, ob);
		return count;
	}

	@Override
	public int addPanDuan(Object[] ob) {
		NewsDaoImpl n=new NewsDaoImpl();
		int addNews = n.addNews(ob);
		return addNews;
	}

	

	
}
