package org.news.service.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import org.news.dao.BaseDao;
import org.news.entity.News;
import org.news.service.NewsService;

public class NewsServiceImpl extends BaseDao implements NewsService{
	//删除某条新闻
	@Override
	public int deleteNews(int nid) {
		// TODO Auto-generated method stub
		int falg = 0;
		String sql="delete from news where nid=?";
		try {
			falg = this.executeUpdate(sql, nid);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			closeAll(conn, null, null);
		}
		return falg;
	}
	
	@Override
	public int addNews(News news) {
		// TODO Auto-generated method stub
		int falg=0;
		SimpleDateFormat sldf = new SimpleDateFormat("yy--MM--dd  HH:mm:ss");
		String date =sldf.format(news.getNcreatedate());
		String sql = "insert into news (ntid,ntitle,nauthor,ncreateDate,"+
		"npicPath,ncontent,nsummary) values ( ? , ? , ? , ? , ? , ? , ?)";
		Object[] ojb={news.getNtid(),news.getNtitle(),news.getNauthor(),date,news.getNpicpath(),news.getNcontent(),news.getNsummary()};
		falg = this.executeUpdate(sql, ojb);
		closeAll(conn, null, null);
		return falg;
	}

	@Override
	public News findNewsByNid(int nid) {
		// TODO Auto-generated method stub
		News news = null;
		ResultSet rs = null;
		String sql = "select * from news where nid=?";
		Object[] obj={nid};
		rs=this.executeQuery(sql, obj);
		try {
			while(rs.next()){
				news=new News();
				news.setNid(rs.getInt("nid"));
				news.setNtid(rs.getInt("ntid"));
				news.setNtitle(rs.getString("ntitle"));
				news.setNauthor(rs.getString("nauthor"));
				news.setNcreatedate(rs.getDate("ncreateDate"));
				news.setNpicpath(rs.getString("npicPath"));
				news.setNcontent(rs.getString("ncontent"));
				news.setNsummary(rs.getString("nsummary"));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			closeAll(conn, null, rs);
		}
		return news;
	}
	


}
