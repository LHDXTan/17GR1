package org.news.service.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.news.dao.BaseDao;
import org.news.entity.Comment;
import org.news.service.CommentService;

public class CommentServiceImpl extends BaseDao implements CommentService {

	@Override
	public List<Comment> getComments(int nid) {
		// TODO Auto-generated method stub
		List<Comment> list=new ArrayList<Comment>();
		ResultSet rs = null;
		String sql ="select cauthor,cip,cdate,ccontent from comments,news where cnid=?"+
		" "+"and comments.cnid=news.nid order by cdate desc";
		Comment cm=null;
		try {
			rs=this.executeQuery(sql, nid);
			while(rs.next()){
				cm=new Comment();
				cm.setCauthor(rs.getString("cauthor"));
				cm.setCip(rs.getString("cip"));
				cm.setCdate(rs.getDate("cdate"));
				cm.setCcontent(rs.getString("ccontent"));
				list.add(cm);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			closeAll(conn, null, rs);
		}
		return list;
	}

}
