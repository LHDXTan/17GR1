package org.news.service;

import org.news.entity.News;

public interface NewsService {
	/**
	 * 删除新闻的方法
	 * @param nid
	 * @return
	 */
	public int deleteNews(int nid);
	/**
	 * 添加新闻的方法
	 */
	public int addNews(News news);
	/**
	 * 根据ID查找新闻的方法
	 */
	public News findNewsByNid(int nid);
}
