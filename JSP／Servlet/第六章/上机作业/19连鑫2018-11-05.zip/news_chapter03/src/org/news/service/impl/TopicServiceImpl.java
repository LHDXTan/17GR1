package org.news.service.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.news.dao.BaseDao;
import org.news.dao.NewsDao;
import org.news.dao.TopicsDao;
import org.news.dao.impl.NewsDaoImpl;
import org.news.dao.impl.TopicsDaoImpl;
import org.news.entity.Topic;
import org.news.service.TopicService;

public class TopicServiceImpl extends BaseDao implements TopicService {

	@Override
	public int deleteTopicBytid(int tid) {
		// TODO Auto-generated method stub
		TopicsDao td = new TopicsDaoImpl();
		NewsDao nd = new NewsDaoImpl();
		
		int count=0;
		int t=0;
		count=nd.getNewsCountByTID(tid);
		if(count>=1){
			return 0;
		}else{
			t = td.deleteTopic(tid);
			return t;
		}
	}

	@Override
	public Topic findTopicByTid(int tid) {
		// TODO Auto-generated method stub
		Topic t = null;
		ResultSet rs = null;
		String sql ="select * from topic where tid = ?";
		Object[] obj = {tid};
		rs = this.executeQuery(sql, obj);
		try {
			while(rs.next()){
				t = new Topic();
				t.setTid(rs.getInt("tid"));
				t.setTname(rs.getString("tname"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			closeAll(conn, null, rs);
		}
		return t;
	}

}
