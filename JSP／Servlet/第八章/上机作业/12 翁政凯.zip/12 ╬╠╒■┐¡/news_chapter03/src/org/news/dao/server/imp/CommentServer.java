package org.news.dao.server.imp;
import org.news.dao.server.CommentUtil;

public class CommentServer implements CommentUtil{

}
