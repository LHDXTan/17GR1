package org.news.dao.server;

public interface CommentUtil {

}
