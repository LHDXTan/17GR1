package com.zuoye.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.zuoye.entiy.User;

public class UserServlet extends HttpServlet {
	
	public void destroy() {
		super.destroy(); 
	}
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		response.setContentType("text/html");
		response.setContentType("text/html");
		String uname = request.getParameter("uname");
		String uchen = request.getParameter("uchen");
		String[] uyu = request.getParameterValues("uyu");
		HttpSession session = request.getSession();
		User user = new User();
		user.setUname(uname);
		user.setUchen(uchen);
		user.setUyu((java.util.Arrays.asList(uyu)));
		session.setAttribute("User", user);
		response.sendRedirect("MyJsp.jsp");
	}
	public void init() throws ServletException {
	}
}
