package com.zuoye.entiy;
import java.util.List;

public class User {
	private String uname;
	private String uchen;
	private List<String> uyu;
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUchen() {
		return uchen;
	}
	public void setUchen(String uchen) {
		this.uchen = uchen;
	}
	public List<String> getUyu() {
		return uyu;
	}
	public void setUyu(List<String> uyu) {
		this.uyu = uyu;
	}
	
}
