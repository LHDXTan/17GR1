package org.news.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.news.dao.NewsDao;
import org.news.dao.impl.NewsDaoImpl;
import org.news.entity.News;
import org.news.service.NewsService;
import org.news.service.impl.NewsServiceImpl;

public class NewsServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public NewsServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		Writer out=response.getWriter();
		HttpSession session = request.getSession();
		String action=request.getParameter("action");
		String nids = request.getParameter("nid");
		NewsDao nd = new NewsDaoImpl();
		NewsService ns = new NewsServiceImpl();
		List<News> listNews =new ArrayList<News>();
		int falg = 0;
		if(action.equals("deleteNews")){
			falg=ns.deleteNews(Integer.parseInt(nids));
			listNews=nd.getAllnews();
			session.setAttribute("listNews", listNews);
			if(falg > 0 ){
				out.write("<script type='text/javascript'>");
				out.write("alert('删除成功!');");
				out.write("</script>");
				response.sendRedirect("newspages/admin.jsp");
			}else{
				out.write("<script type='text/javascript' ");
				out.write("alert('删除失败!');");
				out.write("</script>");
				response.sendRedirect("newspages/admin.jsp");
			}
		}else if(action.equals("updateNews")){
			News news = ns.findNewsByNid(Integer.parseInt(nids));
			session.setAttribute("news", news);
			request.getRequestDispatcher("newspages/news_update.jsp").forward(request, response);
		}

	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		Writer out=response.getWriter();
		HttpSession session = request.getSession();
		NewsDao nd = new NewsDaoImpl();
		List<News> listNews=new ArrayList<News>();
		String action=request.getParameter("action");
		if(action.equals("addnews")){
			//主题ID
			String ntid=(String)request.getParameter("ntid");
			//标题
			String ntitle=(String)request.getParameter("ntitle");
			//作者
			String nauthor=(String)request.getParameter("nauthor");
			//摘要
			String nsummary=(String)request.getParameter("nsummary");
			//内容
			String ncontent=(String)request.getParameter("ncontent");
			//获取图片名称
			String npicpath=(String)request.getParameter("file");
			//获取当前时间
			Date d= new Date();
			int falg = 0;
			NewsService ns = new NewsServiceImpl();
			News news = new News(Integer.parseInt(ntid), ntitle, nauthor, d, npicpath, ncontent, nsummary);
			news.setNmodifydate(d);
			falg=ns.addNews(news);//a=add d=delete u=upadte s=select 返回字母则为成功
			listNews=nd.getAllnews();
			session.setAttribute("listNews",listNews);
			if(falg > 0){
				out.write("<script type='text/javascript'>");
				out.write("alert('添加成功!');");
				out.write("</script>");
				request.getRequestDispatcher("newspages/admin.jsp").forward(request, response);
			}else{
				
				out.write("<script type='text/javascript' ");
				out.write("alert('添加失败!');");
				out.write("</script>");
				response.sendRedirect("newspages/news_add.jsp");
			}
		}
		
		
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
