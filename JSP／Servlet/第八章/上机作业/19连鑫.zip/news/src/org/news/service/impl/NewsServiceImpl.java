package org.news.service.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.news.dao.BaseDao;
import org.news.entity.News;
import org.news.service.NewsService;
import org.news.util.Page;

public class NewsServiceImpl extends BaseDao implements NewsService{
	//删除某条新闻
	@Override
	public int deleteNews(int nid) {
		// TODO Auto-generated method stub
		int falg = 0;
		String sql="delete from news where nid=?";
		try {
			falg = this.executeUpdate(sql, nid);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			closeAll(conn, null, null);
		}
		return falg;
	}
	
	@Override
	public int addNews(News news) {
		// TODO Auto-generated method stub
		int falg=0;
		SimpleDateFormat sldf = new SimpleDateFormat("yy--MM--dd  HH:mm:ss");
		String date =sldf.format(news.getNcreatedate());
		String sql = "insert into news (ntid,ntitle,nauthor,ncreateDate,"+
		"npicPath,ncontent,nsummary,nmodifyDate) values ( ? , ? , ? , ? , ? , ? , ? , ?)";
		Object[] ojb={news.getNtid(),news.getNtitle(),news.getNauthor(),date,news.getNpicpath(),news.getNcontent(),news.getNsummary(),date};
		falg = this.executeUpdate(sql, ojb);
		closeAll(conn, null, null);
		if(falg<1){
			return 0;
		}
		return falg;
	}

	@Override
	public News findNewsByNid(int nid) {
		// TODO Auto-generated method stub
		News news = null;
		ResultSet rs = null;
		String sql = "select * from news where nid=?";
		Object[] obj={nid};
		rs=this.executeQuery(sql, obj);
		try {
			while(rs.next()){
				news=new News();
				news.setNid(rs.getInt("nid"));
				news.setNtid(rs.getInt("ntid"));
				news.setNtitle(rs.getString("ntitle"));
				news.setNauthor(rs.getString("nauthor"));
				news.setNcreatedate(rs.getDate("ncreateDate"));
				news.setNpicpath(rs.getString("npicPath"));
				news.setNcontent(rs.getString("ncontent"));
				news.setNsummary(rs.getString("nsummary"));
				news.setNmodifydate(rs.getDate("nmodifyDate"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			closeAll(conn, null, rs);
		}
		return news;
	}

	@Override
	public int updateNewsById(News news) {
		// TODO Auto-generated method stub
		int falg=0;
		String sql = "update news set ntid=? , ntitle=? , nauthor=? , "+
		"npicPath=? , ncontent=? , nsummary=? , nmodifyDate=? where nid = ?";
		Object [] obj={
			news.getNtid(),news.getNtitle(),news.getNauthor(),
			news.getNpicpath(),news.getNcontent(),news.getNsummary(),
			news.getNmodifydate(),news.getNid()
		};
		falg=this.executeUpdate(sql, obj);
		closeAll(conn, null, null);
		if(falg<1){
			return 0;
		}
		return falg;
	}

	@Override
	public int findAllNewCount() {
		// TODO Auto-generated method stub
		int count = -1;
		ResultSet rs = null;
		String sql = "select count(1) from news";
		try {
			rs=this.executeQuery(sql);
			while(rs.next()){
				count=rs.getInt(1);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			closeAll(conn, null, rs);
		}
		return count;
	}

	/**@Override
	public int findNewsPageCount() {
		// TODO Auto-generated method stub
		//15个新闻为一页
		int countPage = 1;//总页数
		int count = -1;//总数
		count=this.findAllNewCount();
		countPage = count % 15 == 0 ? count / 15 : count / 15 + 1;
		closeAll(conn, null, null);
		return countPage;
	}**/

	@Override
	public List<News> findNewsPageIndex(Page page) {
		// TODO Auto-generated method stub
		int index = -1;
		ResultSet rs = null;
		List<News> list=new ArrayList<News>();
		News news = null;
		index= (page.getPageNow()-1)*15;//起始行的下标=(当前页码-1)*每页显示的数量
		String sql = "select * from news limit ? , 15";
		Object[] obj={index};
		try {
			rs=this.executeQuery(sql, obj);
			while(rs.next()){
				news = new News();
				news.setNid(rs.getInt("nid"));
				news.setNtid(rs.getInt("ntid"));
				news.setNtitle(rs.getString("ntitle"));
				news.setNauthor(rs.getString("nauthor"));
				news.setNcreatedate(rs.getDate("ncreateDate"));
				news.setNpicpath(rs.getString("npicPath"));
				news.setNcontent(rs.getString("ncontent"));
				news.setNsummary(rs.getString("nsummary"));
				news.setNmodifydate(rs.getDate("nmodifyDate"));
				list.add(news);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			closeAll(conn, null, rs);
		}
		return list;
	}
	


}
