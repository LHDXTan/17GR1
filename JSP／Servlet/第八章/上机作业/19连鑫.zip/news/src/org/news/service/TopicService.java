package org.news.service;

import org.news.entity.Topic;

public interface TopicService {
	/**
	 * 判断该主题下是否有新闻，如果没有就删除，有就不删除
	 * @param tid
	 * @return
	 */
	public int deleteTopicBytid(int tid);
	/**
	 * 根据主题ID查找主题名字的方法
	 */
	public Topic findTopicByTid(int tid);
	
}
