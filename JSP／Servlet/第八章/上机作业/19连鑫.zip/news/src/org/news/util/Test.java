package org.news.util;

import org.news.service.NewsService;
import org.news.service.impl.NewsServiceImpl;

public class Test {
	public static void main(String[] args) {
		NewsService ns = new NewsServiceImpl();
		System.out.println(ns.findAllNewCount());
	}
}
