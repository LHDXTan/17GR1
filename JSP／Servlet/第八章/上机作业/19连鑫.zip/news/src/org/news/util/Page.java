package org.news.util;

import java.util.List;

import org.news.entity.News;

public class Page {
	//总页数
	private int totalPageCount=0;
	//每页的数量
	private int pageSize=15;
	//记录总数
	private int totalCount;
	//当前页码
	private int pageNow=1;
	//每页新闻集合
	private List<News> newsList;
	public int getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(int totalCount) {
		if(totalCount > 0){
			this.totalCount = totalCount;
			//记录总页数
			totalPageCount=this.totalCount % pageSize == 0 ?(this.totalCount / pageSize) 
					: (this.totalCount / pageSize + 1);
		}
	}	
	public int getTotalPageCount() {
		return totalPageCount;
	}
	public void setTotalPageCount(int totalPageCount) {
		this.totalPageCount = totalPageCount;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		if(pageSize > 0)
		this.pageSize = pageSize;
	}

	public int getPageNow() {
		//如果总页数为0 则返回0
		if(totalPageCount == 0){
			return 0;
		}
		return pageNow;
	}
	public void setPageNow(int pageNow) {
		if(pageNow > 0)
		this.pageNow = pageNow;
	}
	public List<News> getNewsList() {
		return newsList;
	}
	public void setNewsList(List<News> newsList) {
		this.newsList = newsList;
	}
	
	
}
