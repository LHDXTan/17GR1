package org.news.service.impl;

import org.news.dao.BaseDao;
import org.news.dao.impl.NewsDaoImpl;
import org.news.service.NewsService;

public class NewsServiceImpl extends  BaseDao implements NewsService{

	@Override
	public String delPanDan(int id) {
		NewsDaoImpl nd=new NewsDaoImpl();
		int delNewId=nd.delNewId(id);
		String yy="";
		if(delNewId==1){
			yy="删除成功";
			return yy;
		}else{
			yy="删除失败";
		}
		return yy;
	}

	

}
