package org.news.service;

import java.util.List;

import org.news.entity.Comment;

public interface CommentService {
	public List<Comment> getComments(int nid);
}
