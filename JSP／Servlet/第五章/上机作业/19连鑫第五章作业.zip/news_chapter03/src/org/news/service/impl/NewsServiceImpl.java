package org.news.service.impl;

import org.news.dao.BaseDao;
import org.news.service.NewsService;

public class NewsServiceImpl extends BaseDao implements NewsService{
	//删除某条新闻
	@Override
	public int deleteNews(int nid) {
		// TODO Auto-generated method stub
		int falg = 0;
		String sql="delete from news where nid=?";
		try {
			falg = this.executeUpdate(sql, nid);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			closeAll(conn, null, null);
		}
		return falg;
	}


}
