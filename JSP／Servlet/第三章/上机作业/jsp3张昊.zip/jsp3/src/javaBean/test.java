package javaBean;

import java.sql.SQLException;

import DAO.BaseDao;

public class test {
public static void main(String[] args) throws ClassNotFoundException, SQLException {
	BaseDao ba = new BaseDao();
	 Person name = ba.findbyName("admin");
	System.out.println( name.toString());
}
}
