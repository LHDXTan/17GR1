package com.Empity;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.Dao.BaseDao;

public class Test {
	public User findUser(){
		String sql="select * from news_users";
		Connection conn=BaseDao.getCon();
		PreparedStatement ps=null;
		ResultSet rs =null;
		try {
			ps = conn.prepareStatement(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		User u = null;
		try {
			rs = ps.executeQuery();
			while(rs.next()){
				u=new User();
				u.setName(rs.getString("uname"));
				u.setPwd(rs.getString("upwd"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			conn.close();
			ps.close();
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return u;
		
	}
//	public static void main(String[] args) {
//		User user = new User();
//		Test t=new Test();
//		user=t.findUser();
//		System.out.println(user.getName()+"   "+user.getPwd());
//	}
}
