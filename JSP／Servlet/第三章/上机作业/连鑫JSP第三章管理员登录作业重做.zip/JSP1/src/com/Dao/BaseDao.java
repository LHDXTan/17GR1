package com.Dao;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

public class BaseDao {


	//import com.mysql.jdbc.Driver;

		private static String driver;
		private static String url;
		private static String username;
		private static String password;
		static{
			Properties pt = new Properties();
			InputStream is = BaseDao.class.getClassLoader().getResourceAsStream("jdbc.properties");
			try {
				pt.load(is);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 driver = pt.getProperty("driver");
			 url = pt.getProperty("url");
			 username = pt.getProperty("username");
			 password = pt.getProperty("password");
		}
		public static void colseAll(ResultSet rs,Connection con,PreparedStatement ps){
				try {
					if(rs!=null){
					rs.close();
					}
					if(ps!=null){
						ps.close();
					}
					if(con!=null){
						con.close();
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		public static Connection getCon(){
			try {
				Class.forName(driver);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Connection con = null;
			try {
				con = DriverManager.getConnection(url, username, password);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return con;
			
		}
		
		

}
