package org.news.service;

import java.util.List;

import org.news.entity.News;
import org.news.util.Page;

public interface NewsService {
	/**
	 * 删除新闻的方法
	 * @param nid
	 * @return
	 */
	public int deleteNews(int nid);
	/**
	 * 添加新闻的方法
	 */
	public int addNews(News news);
	/**
	 * 根据ID查找新闻的方法
	 */
	public News findNewsByNid(int nid);
	/**
	 * 更新新闻的方法
	 */
	public int updateNewsById(News news);
	/**
	 * 获取新闻总数
	 */
	public int findAllNewCount();
	/**
	 * 获取新闻总页数
	 */
	//public int findNewsPageCount();
	/**
	 * 根据索引数返回该页新闻
	 */
	public List<News> findNewsPageIndex(Page page);
}
