package entity;
/**
 * 订单详情：存放订单具体信息
 * @author lenovo
 *
 */
public class Order_detail {
		private int id;//���
		private int orderId;//订单ID
		private int productId;//商品ID
		private int quantity;//数量
		private int cost;//金额
		
		public Order_detail() {
			super();
			// TODO Auto-generated constructor stub
		}
		public Order_detail(int id, int orderId, int productId, int quantity,
				int cost) {
			super();
			this.id = id;
			this.orderId = orderId;
			this.productId = productId;
			this.quantity = quantity;
			this.cost = cost;
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public int getOrderId() {
			return orderId;
		}
		public void setOrderId(int orderId) {
			this.orderId = orderId;
		}
		public int getProductId() {
			return productId;
		}
		public void setProductId(int productId) {
			this.productId = productId;
		}
		public int getQuantity() {
			return quantity;
		}
		public void setQuantity(int quantity) {
			this.quantity = quantity;
		}
		public int getCost() {
			return cost;
		}
		public void setCost(int cost) {
			this.cost = cost;
		}
		
		
}
