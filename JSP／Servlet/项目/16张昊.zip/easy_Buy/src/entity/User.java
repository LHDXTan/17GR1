package entity;

import java.util.Date;
/**
 * 用户表：存放用户基本信息
 * @author lenovo
 *
 */
public class User {
	private int Id;//
	private String loginName;//	用户名
	private String userName;//	用户真实姓名
	private String password;//密码
	private String sex;//	性别
	private String identityCode;// 身份证号
	private String email;//email	
	private String mobile;	//手机
	private int type;//类型
	
	public User() {
	}

	public User(int id, String loginNmae, String userName, String password,
			String sex, String identityCode, String email, String mobile, int type) {
		super();
		Id = id;
		this.loginName = loginName;
		this.userName = userName;
		this.password = password;
		this.sex = sex;
		this.identityCode = identityCode;
		this.email = email;
		this.mobile = mobile;
		this.type = type;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getIdentityCode() {
		return identityCode;
	}

	public void setIdentityCode(String identityCode) {
		this.identityCode = identityCode;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}	
	
	
}
