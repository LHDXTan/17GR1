package dao.Impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.BaseDao;
import dao.ProductDao;
import entity.Product;

public class ProductImpl extends BaseDao implements ProductDao {
	@Override
	public Product getProductById(int id) {
		String sql = "select * from easybuy_product where id = ?";
		ResultSet rs = this.executeQuery(sql);
		Product product = null;
		try {
			while(rs.next()){
				product = new Product();
				product.setId(id);
				product.setName(rs.getString("name"));
				product.setDescription(rs.getString("description"));
				product.setPrice(rs.getFloat("price"));
				product.setStock(rs.getInt("stock"));
				/*product.setCategoryLevel1(rs.getInt("categoryLevel1"));
				product.setCategoryLevel2(rs.getInt("categoryLevel2"));
				product.setCategoryLevel3(rs.getInt("categoryLevel3"));*/
				product.setFileName(rs.getString("fileName"));
				product.setIsDelete(rs.getString("isDelete"));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return product;
	}

	@Override
	public List<Product> selectProduct() {
		String sql = "select * from easybuy_product";;
		ResultSet rs = this.executeQuery(sql);
		ArrayList<Product> list = new ArrayList<Product>();
		
		try {
			while(rs.next()){
				int id = rs.getInt("id");
				String name = rs.getString("name");
				String description = rs.getString("description");
				float price = rs.getFloat("price");
				int stock = rs.getInt("stock");
				/*int categoryLevel1 = rs.getInt("categoryLevel1");
				int categoryLevel2 = rs.getInt("categoryLevel2");
				int categoryLevel3 = rs.getInt("categoryLevel3");*/
				String fileName = rs.getString("fileName");
				String isDelete = rs.getString("isDelete");
				Product product = new Product(id, name, description, price, stock, fileName, isDelete);
				
				list.add(product);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

}
