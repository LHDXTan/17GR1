package dao.Impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.BaseDao;
import dao.ProductCategoryDao;
import dao.ProductCategoryVo;
import entity.ProductCategory;

public class ProductCategoryImpl extends BaseDao implements ProductCategoryDao{

	@Override
	public ProductCategory getById(Integer id) {
		String sql = "select * from easybuy_product_category where id = ?";
		ResultSet rs = this.executeQuery(sql, id);
		ProductCategory productCategory = null;
		try {
			while(rs.next()){
				 productCategory = new ProductCategory();
				 productCategory.setId(id);
				 productCategory.setName(rs.getString("name"));
				 productCategory.setParentId(rs.getInt("parentId"));
				 productCategory.setType(rs.getInt("type"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return productCategory;
	}

	@Override
	public List<ProductCategory> queryProductCategoryList() {
		String sql = "select * from easybuy_product_category";
		ResultSet rs = super.executeQuery(sql);
		ArrayList<ProductCategory> list = new ArrayList<ProductCategory>();
		try {
			while(rs.next()){
				int id = rs.getInt("id");
				String name = rs.getString("name");
				int parentId = rs.getInt("parentId");
				int type = rs.getInt("type");
				ProductCategory productCategory = new ProductCategory(id, name, parentId, type);
				list.add(productCategory);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public int queryProductCategoryCount(int id) {
		String sql = "select count(id) from easybuy_product_category";
		int count = -1;
		try {
			ResultSet rs = this.executeQuery(sql);
			rs.next();
			 count = rs.getInt(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}

	@Override
	public int addProductCategory(ProductCategory productcategory) {
		String sql = "insert into easybuy_product_category(name,parentId,type) values(?,?,?)";
		return executeUpdate(sql, new Object[]{productcategory.getName(),productcategory.getParentId(),productcategory.getType()});
	}

	@Override
	public int deleteById(Integer id) {
		String sql = "delete from easybuy_product_category where id = ?";
		int update = this.executeUpdate(sql, id);
		return update;
	}

	@Override
	public int modifyProductCategory(ProductCategory productcategory) {
		String sql = "update easybuy_product_category set name=?,parentId=?,type=?";
		return executeUpdate(sql, new Object[]{productcategory.getName(),productcategory.getParentId(),productcategory.getType()});
	}
	
	
	
	@Override
	public List<ProductCategory> getProductCategories(Integer parentId) {
		String sql = "select * from easybuy_product_category where parentId = ?";
		ResultSet rs = super.executeQuery(sql);
		ArrayList<ProductCategory> list = new ArrayList<ProductCategory>();
		try {
			while(rs.next()){
				int id = rs.getInt("id");
				String name = rs.getString("name");
				int parentId1 = rs.getInt("parentId");
				int type = rs.getInt("type");
				ProductCategory productCategory = new ProductCategory();
				list.add(productCategory);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public List<ProductCategoryVo> queryAllProductCategoryList() {
		//查询一级分类列表
		 ArrayList<ProductCategoryVo> productCategory1VoList = new ArrayList<ProductCategoryVo>();
		 //查询一级分类
		 List<ProductCategory> productCategory1List = this.getProductCategories(null);
		 //遍历，分类，根据一级分类ID查询二级分类
		 for(ProductCategory productCategory1 : productCategory1List ){
			 //封装一级分类
			 ProductCategoryVo productCategoryVo = new ProductCategoryVo();
			 
			 //把一级分类放进Vo里
//			 productCategoryVo.setProductCategory(product1Category);
			 //把二级放进list
			 ArrayList<ProductCategoryVo> productCategoryVo1ChildList = new ArrayList<ProductCategoryVo>();
				 
		 }
		return null;
	}


}
