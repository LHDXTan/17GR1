package dao.Impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.BaseDao;
import dao.NewsDao;
import entity.News;

public class NewsDaoImpl extends BaseDao implements NewsDao {

	@Override
	public News getNewsById(int id) {
		String sql = "select * from easybuy_news where id = ?";
		ResultSet rs = this.executeQuery(sql);
		News news = null;
		try {
			while(rs.next()){
			 news = new News();
			 news.setId(id);
			 news.setTitle(rs.getString("title"));
			 news.setContent(rs.getString("content"));
			 news.setCreateTime(rs.getString("createTime"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return news;
	}

	@Override
	public List<News> selectNews() {
		String sql = "select * from easybuy_news";
		ResultSet rs = this.executeQuery(sql);
		ArrayList<News> list = new ArrayList<News>();
		try {
			while(rs.next()){
				int id = rs.getInt("id");
				String title = rs.getString("title");
				String content = rs.getString("content");
				String createTime = rs.getString("createTime");
				News news = new News(id, title, content, createTime);
				list.add(news);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

}
