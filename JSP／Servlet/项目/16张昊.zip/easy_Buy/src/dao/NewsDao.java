package dao;

import java.util.List;

import entity.News;

public interface NewsDao {
	/**
	 * 根据id查询新闻
	 * @param id
	 * @return
	 */
	public News getNewsById(int id);
	/**
	 * 查询新闻资讯
	 * @return
	 */
	public List<News> selectNews();
}
