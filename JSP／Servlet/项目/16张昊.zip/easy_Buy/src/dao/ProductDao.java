package dao;

import java.util.List;

import entity.Product;

public interface ProductDao {
 /**
  * 根据id查询商品
  */
	public Product getProductById(int id);
/**
 * 查询所有商品详情
 */
	public List<Product> selectProduct();
}
