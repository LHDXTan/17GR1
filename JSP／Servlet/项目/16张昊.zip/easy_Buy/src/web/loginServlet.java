package web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UserDao;
import dao.Impl.UserDaoimpl;
import entity.User;

public class loginServlet extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		 String contextPath = request.getContextPath();
		String loginName = request.getParameter("loginname");
//		System.out.println(loginName);
		String password = request.getParameter("password");
//		System.out.println(password);
		UserDao userdao = new UserDaoimpl();
		 User user2 = new User();
		 user2.setLoginName(loginName);
		 user2.setPassword(password);
		 
		 User findUser = userdao.findUser(loginName, password);
//		 System.out.println(findUser);
		 if(findUser == null){
			 out.print("<script type=\"text/javascript\">");
             out.print("alert(\"用户名密码错误，请重新登录\");");
             out.print("open(\"" + contextPath
                     + "/Login.jsp\",\"_self\");");
             out.print("</script>");
		 }else{
			 request.getSession().setAttribute("admin",loginName );
//			 request.getRequestDispatcher("Index.jsp").forward(request, response);
			 response.sendRedirect("Index.jsp");
		 }
//		System.out.println(password);
//		List<User> list = userdao.getUser();
//		for(User user : list){
//			System.out.println(user.getLoginName());
//		}
////		if(username.equals(user.getLoginName())&&password.equals(user.getPassword())){
////			System.out.println("1123");
//////			response.sendRedirect("Index.jsp");
////		}
		out.flush();
		out.close();
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.print("    This is ");
		out.print(this.getClass());
		out.println(", using the POST method");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

}
