package com.easybuy.entity;
//�û���
public class easybuy_user {
	private int id;
	private String loglnName;//�û���
	private String userName;//�û���ʵ����
	private String password;//����
	private String sex;//�Ա�
	private String identityCode;//����֤��
	private String email;//email
	private String moblle;//�ֻ�
	private int type;//���� 1Ϊ��ͨ�û� 2Ϊ����Ա
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getLoglnName() {
		return loglnName;
	}
	public void setLoglnName(String loglnName) {
		this.loglnName = loglnName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getIdentityCode() {
		return identityCode;
	}
	public void setIdentityCode(String identityCode) {
		this.identityCode = identityCode;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMoblle() {
		return moblle;
	}
	public void setMoblle(String moblle) {
		this.moblle = moblle;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	
	

}
