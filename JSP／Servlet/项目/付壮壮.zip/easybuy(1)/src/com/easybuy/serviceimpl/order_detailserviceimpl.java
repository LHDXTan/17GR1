package com.easybuy.serviceimpl;

import com.easybuy.service.order_detailservice;
import com.easybuy.service.orderservice;

public class order_detailserviceimpl implements order_detailservice {

}
