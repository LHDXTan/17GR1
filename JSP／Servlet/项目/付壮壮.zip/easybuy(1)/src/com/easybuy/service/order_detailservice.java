package com.easybuy.service;

public interface order_detailservice {
	

}
