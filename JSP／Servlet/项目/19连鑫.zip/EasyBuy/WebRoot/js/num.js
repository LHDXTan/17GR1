// JavaScript Document


function addUpdate(jia){		
	var c = jia.parent().find(".n_ipt").val();
	c=parseInt(c)+1;	
	jia.parent().find(".n_ipt").val(c);
}

function jianUpdate(jian){    
	var c = jian.parent().find(".n_ipt").val();
	
	if(c == 1){    
		c=2;   
	}
		c=parseInt(c)-1;   
		jian.parent().find(".n_ipt").val(c);
}    




function addUpdate1(jia){		
	var c = jia.parent().find(".car_ipt").val();
	var d = jia.parent().parent().next().find("span").text();
	var r = jia.parent().parent().next().next().find("span").text();
	var p = parseFloat(d)/parseInt(c);
	var q = parseInt(r)/parseInt(c);
	c=parseInt(c)+1;	
	d=p*parseInt(c);
	r=q*parseInt(c);
	jia.parent().find(".car_ipt").val(c);
	jia.parent().parent().next().find("span").text(d+".00");
	jia.parent().parent().next().next().find("span").text(r);
}

function jianUpdate1(jian){    
	var c = jian.parent().find(".car_ipt").val();
	var d = jian.parent().parent().next().find("span").text();
	var r = jian.parent().parent().next().next().find("span").text();
	var p = parseFloat(d)/parseInt(c);
	var q = parseInt(r)/parseInt(c);
	if(c==1){    
		c=1;    
	}else{
		c=parseInt(c)-1;    
		d=p*parseInt(c);
		r=q*parseInt(c);
		jian.parent().find(".car_ipt").val(c);
		jian.parent().parent().next().find("span").text(d+".00");
		jian.parent().parent().next().next().find("span").text(r);
	}
}

