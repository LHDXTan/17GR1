package com.easy.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.ws.rs.core.Application;

import com.easy.dao.UserDao;
import com.easy.dao.impl.UserDaoImpl;
import com.easy.entity.News;
import com.easy.entity.Product;
import com.easy.entity.Product_categoryVO;
import com.easy.entity.User;
import com.easy.service.NewsService;
import com.easy.service.ProductService;
import com.easy.service.Product_categoryService;
import com.easy.service.impl.NewsServiceImpl;
import com.easy.service.impl.ProductServiceImpl;
import com.easy.service.impl.Product_categoryServiceImpl;
import com.alibaba.fastjson.JSON;
public class EasyBuyServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public EasyBuyServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		this.doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		PrintWriter out = response.getWriter();
		String action = request.getParameter("action");
		String op = request.getParameter("op");
		System.out.println(action);
		HttpSession session = request.getSession();
		UserDao ud = new UserDaoImpl();
		List<Product> listp = null;
		listp=(List<Product>) session.getAttribute("listp");
		if(listp == null){
			listp = new ArrayList<Product>();
		}
		if("login".equals(action)){//登录
			String loginName = request.getParameter("loginName");
			String password = request.getParameter("password");
			User user = ud.findUserByName(loginName);
			if(user != null && password.equals(user.getPassword())){
				session.setAttribute("user", user);
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}
		}else if("regist".equals(action)){//注册
			String userName = request.getParameter("userName");
			String password = request.getParameter("password");
			String email = request.getParameter("email");
			String mobile = request.getParameter("mobile");
			User u = null;
			User user = ud.findUserByName(userName);
			if(user!=null){
				
			}else{
				u = new User();
				u.setLoginName(userName);
				u.setPassword(password);
				u.setEmail(email);
				u.setMobile(mobile);
				int addUser = ud.addUser(u);
				if(addUser >= 1){
					response.sendRedirect("login.jsp?opr=1");
				}else{
					response.sendRedirect("regist.jsp?opr=0");
				}
			}
		}else if("regists".equals(action)){//注册查询用户是否已被注册 ajax异步查询
			String userName = request.getParameter("userName");
			System.out.println(action);
			System.out.println(userName);
			User user = ud.findUserByName(userName);
			if(user != null){
				out.write("0");
			}else{
				out.write("1");
			}
			
		}else if("logout".equals(action)){
			session.removeAttribute("user");
			response.sendRedirect("login.jsp");
		}else if("list".equals(action)){
			Product_categoryService ps = new Product_categoryServiceImpl();
			NewsService ns = new NewsServiceImpl();
			List<News> allNews = ns.getAllNews();
			List<Product_categoryVO> allList = ps.getAllList();
			ProductService pp = new ProductServiceImpl();
			List<Product> teMai = pp.getTeMai();
			for (Product_categoryVO VO : allList) {
				System.out.println(VO.getPc().getName());
				for (Product_categoryVO VO2 : VO.getList()) {
					System.out.println(VO2.getPc().getName());
				}
			}
			session.setAttribute("allNews", allNews);
			session.setAttribute("voList", allList);
			session.setAttribute("TeMai", teMai);
			if(("buy").equals(op)){
				request.getRequestDispatcher("buycar.jsp").forward(request, response);
			}else if(("pro").equals(op)){
				request.getRequestDispatcher("product.jsp").forward(request, response);
			}else{
				request.getRequestDispatcher("index.jsp").forward(request, response);
				
			}
		}else if("product".equals(action)){
			ProductService ps = new ProductServiceImpl();
			String sid = request.getParameter("id");
			int id = Integer.parseInt(sid);
			Product productByID = ps.getProductByID(id);
			session.setAttribute("Productqwe", productByID);
			request.getRequestDispatcher("product.jsp").forward(request, response);
		}else if("addBuyCar".equals(action)){
			String id = request.getParameter("ProductASD");
			ProductService ps = new ProductServiceImpl();
			Product product = ps.getProductByID(Integer.parseInt(id));
			listp.add(product);
			session.setAttribute("listp",listp);
			out.print("1");
		}else if("newsList".equals(action)){
			
		}
		out.flush();
		out.close();
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
