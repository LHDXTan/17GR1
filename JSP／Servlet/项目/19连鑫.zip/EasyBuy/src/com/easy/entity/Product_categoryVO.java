package com.easy.entity;

import java.util.List;

/**
 * 商品分类集合
 * @author Administrator
 *
 */
public class Product_categoryVO {
	/**
	 * 商品分类:带有本类和子类集合的类
	 */
	private Product_category pc;
	private List<Product_categoryVO> list;
	
	
	public List<Product_categoryVO> getList() {
		return list;
	}

	public void setList(List<Product_categoryVO> list) {
		this.list = list;
	}

	public Product_category getPc() {
		return pc;
	}

	public void setPc(Product_category pc) {
		this.pc = pc;
	}

	
	
	
	
}
