package com.easy.service;

import java.util.List;

import com.easy.entity.Product;
import com.easy.entity.Product_category;
import com.easy.entity.Product_categoryVO;

/**
 * 商品分类服务方法
 * @author Administrator
 *
 */
public interface Product_categoryService {
	/**
	 * ???
	 * @return
	 */
	public List<Product_categoryVO> getAllList();
	/**
	 * 购物车物品的方法
	 */
	public List<Product> getBuyCarList(Integer id);
}

