package com.easy.service.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.easy.dao.BaseDao;
import com.easy.entity.News;
import com.easy.service.NewsService;

/**
 * 新闻接口实现类
 * @author Administrator
 *
 */
public class NewsServiceImpl extends BaseDao implements NewsService{

	@Override
	public List<News> getAllNews() {
		// TODO Auto-generated method stub
		List<News> list = new ArrayList<News>();
		News n = null;
		ResultSet rs = null;
		String sql = "select * from easybuy_news order by createTime desc";
		try {
			rs = this.executeQuery(sql);
			while(rs.next()){
				n = new News();
				n.setId(rs.getInt("id"));
				n.setTitle(rs.getString("title"));
				n.setContent(rs.getString("content"));
				n.setCreateTime(rs.getDate("createTime"));
				list.add(n);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			closeAll(conn, null, rs);
		}
		return list;
	}

}
