package com.easy.service;

import java.util.List;

import com.easy.entity.News;

/**
 * 新闻的接口
 * @author Administrator
 *
 */
public interface NewsService {
	/**
	 * 获取所有的新闻
	 * @return
	 */
	public List<News> getAllNews();
}
