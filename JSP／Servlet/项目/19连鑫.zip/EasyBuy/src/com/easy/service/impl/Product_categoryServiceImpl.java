package com.easy.service.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.easy.dao.BaseDao;
import com.easy.dao.Product_categoryDao;
import com.easy.dao.impl.Product_categoryDaoImpl;
import com.easy.entity.Product;
import com.easy.entity.Product_category;
import com.easy.entity.Product_categoryVO;
import com.easy.service.Product_categoryService;

public class Product_categoryServiceImpl extends BaseDao implements Product_categoryService{
	/**
	 * 
	 */
	

	@Override
	public List<Product_categoryVO> getAllList() {
		// TODO Auto-generated method stub
		List<Product_categoryVO> listVO1 = new ArrayList<Product_categoryVO>();
		Product_categoryDao pd = new Product_categoryDaoImpl();
		List<Product_category> product1 = pd.getProductByID(null);//获取一级菜单
		for (Product_category product_category : product1) {//循环一级菜单
			
			Product_categoryVO vo1 = new Product_categoryVO();
			List<Product_categoryVO> vo1clist = new ArrayList<Product_categoryVO>();
			List<Product_category> product2 = pd.getProductByID(product_category.getType());
			for (Product_category product_category2 : product2) {
				Product_categoryVO vo2 = new Product_categoryVO();
				List<Product_categoryVO> voc2clist = new ArrayList<Product_categoryVO>();
				List<Product_category> product3 = pd.getProductByID(product_category2.getType());
				for (Product_category product_category3 : product3) {
					Product_categoryVO vo3 = new Product_categoryVO();
					vo3.setPc(product_category3);
					voc2clist.add(vo3);
				}
				vo2.setPc(product_category2);
				vo2.setList(voc2clist);
				vo1clist.add(vo2);
			}
			vo1.setPc(product_category);
			vo1.setList(vo1clist);
			listVO1.add(vo1);
		}
		return listVO1;
	}

	@Override
	public List<Product> getBuyCarList(Integer id) {
		// TODO Auto-generated method stub
		List<Product> list = new ArrayList<Product>();
		ResultSet rs = null;
		Product p = null;
		String sql = "select * from easybuy_product where id = ?";
		Object [] obj = {id};
		try {
			rs = this.executeQuery(sql, obj);
			while(rs.next()){
				p = new Product();
				p.setId(rs.getInt("id"));
				p.setName(rs.getString("name"));
				p.setDescription(rs.getString("description"));
				p.setPrice(rs.getFloat("price"));
				p.setStock(rs.getInt("stock"));
				p.setCategoryLevel1(rs.getInt("categoryLevel1"));
				p.setCategoryLevel2(rs.getInt("categoryLevel2"));
				p.setCategoryLevel3(rs.getString("categoryLevel3"));
				p.setFileName(rs.getString("fileName"));
				p.setIsDelete(rs.getInt("isDelete"));
				list.add(p);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			closeAll(conn, null, rs);
		}
		return list;
	}

}

