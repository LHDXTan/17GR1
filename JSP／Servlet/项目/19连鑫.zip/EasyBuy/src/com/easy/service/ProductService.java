package com.easy.service;

import java.util.List;

import com.easy.entity.Product;

/**
 * 商品的方法
 * @author Administrator
 *
 */
public interface ProductService {
	/**
	 *根据ID查询商品的详细信息
	 * @param id
	 * @return
	 */
	public Product getProductByID(Integer id);
	/**
	 * 获得特卖商品信息
	 * @return
	 */
	public List<Product> getTeMai();
	
}
