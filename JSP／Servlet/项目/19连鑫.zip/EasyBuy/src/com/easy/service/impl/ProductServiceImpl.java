package com.easy.service.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.easy.dao.BaseDao;
import com.easy.entity.Product;
import com.easy.service.ProductService;

public class ProductServiceImpl extends BaseDao implements ProductService {

	@Override
	public Product getProductByID(Integer id) {
		// TODO Auto-generated method stub
		ResultSet rs = null;
		Product p =null;
		String sql = "select * from easybuy_product where id = ?";
		Object obj=id;
		try {
			rs=this.executeQuery(sql, obj);
			while(rs.next()){
				p = new Product();
				p.setId(rs.getInt("id"));
				p.setName(rs.getString("name"));
				p.setDescription(rs.getString("description"));
				p.setPrice(rs.getFloat("price"));
				p.setStock(rs.getInt("stock"));
				p.setCategoryLevel1(rs.getInt("categoryLevel1"));
				p.setCategoryLevel2(rs.getInt("categoryLevel2"));
				p.setCategoryLevel3(rs.getString("categoryLevel3"));
				p.setFileName(rs.getString("fileName"));
				p.setIsDelete(rs.getInt("isDelete"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			closeAll(conn, null, rs);
		}
		return p;
	}

	@Override
	public List<Product> getTeMai() {
		// TODO Auto-generated method stub
		List<Product> lp = new ArrayList<Product>();
		Product p = null;
		ResultSet rs = null;
		String sql = "select * from easybuy_product where id in (6,7,8,9,10,11,12,13,14,15)";
		try {
			rs = this.executeQuery(sql);
			while(rs.next()){
				p = new Product();
				p.setId(rs.getInt("id"));
				p.setName(rs.getString("name"));
				p.setDescription(rs.getString("description"));
				p.setPrice(rs.getFloat("price"));
				p.setStock(rs.getInt("stock"));
				p.setCategoryLevel1(rs.getInt("categoryLevel1"));
				p.setCategoryLevel2(rs.getInt("categoryLevel2"));
				p.setCategoryLevel3(rs.getString("categoryLevel3"));
				p.setFileName(rs.getString("fileName"));
				p.setIsDelete(rs.getInt("isDelete"));
				lp.add(p);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			closeAll(conn, null, rs);
		}
		return lp;
	}
	
}
