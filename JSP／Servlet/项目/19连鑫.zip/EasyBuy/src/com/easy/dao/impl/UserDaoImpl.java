package com.easy.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.easy.dao.BaseDao;
import com.easy.dao.UserDao;
import com.easy.entity.User;

public class UserDaoImpl extends BaseDao implements UserDao {

	@Override
	public User findUserByName(String name) {
		// TODO Auto-generated method stub
		ResultSet rs = null;
		User u = null;
		String sql = "select * from easybuy_user where loginName = ?";
		Object[] obj = {name};
		try {
			rs = this.executeQuery(sql, obj);
			while(rs.next()){
				u = new User();
				u.setId(rs.getInt("id"));
				u.setLoginName(rs.getString("loginName"));
				u.setUserName(rs.getString("userName"));
				u.setPassword(rs.getString("password"));
				u.setSex(rs.getString("sex"));
				u.setIdentityCode(rs.getString("identityCode"));
				u.setEmail(rs.getString("email"));
				u.setMobile(rs.getString("mobile"));
				u.setType(rs.getInt("type"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			closeAll(conn, null, rs);
		}
		return u;
	}

	@Override
	public int addUser(User user) {
		// TODO Auto-generated method stub
		int num = 0;
		String sql = "insert into easybuy_user(loginName,password,email,mobile) values(?,?,?,?)";
		Object[] object={user.getLoginName(),user.getPassword(),user.getEmail(),user.getMobile()};
		num=this.executeUpdate(sql, object);
		closeAll(conn, null, null);
		return num;
	}

	@Override
	public int updateUser(User u) {
		// TODO Auto-generated method stub
		int sum = 0;
		String sql ="update easybuy_user set loginName=?,userName=?,password=?,sex=?,identityCode=?,email=?,mobile=?,type=?";
		Object[] obj={u.getLoginName(),u.getUserName(),u.getPassword(),u.getPassword(),u.getSex(),u.getIdentityCode(),u.getEmail(),u.getMobile(),u.getType()};
		sum=this.executeUpdate(sql, obj);
		closeAll(conn, null, null);
		return sum;
	}

	@Override
	public int deleteUser(String name) {
		// TODO Auto-generated method stub
		int sum = 0;
		String sql = "delete from easybuy_user where loginName = ?";
		Object[] obj={name};
		sum = this.executeUpdate(sql, obj);
		closeAll(conn, null, null);
		return sum;
	}

}
