package com.easy.dao;

import javax.servlet.http.HttpSession;

import com.easy.dao.impl.UserDaoImpl;
import com.easy.entity.User;

/**
 * 用户表的方法
 * @author Administrator
 *
 */
public interface UserDao {
	/**
	 * 根据登录名寻找用户
	 * @param name
	 * @return
	 */
	public User findUserByName(String name);
	/**
	 * 添加用户的方法
	 * @param user
	 * @return
	 */
	public int addUser(User user);
	/**
	 * 修改用户的方法
	 * @param name
	 * @return
	 */
	public int updateUser(User u);
	/**
	 * 删除用户的方法
	 * @param name
	 * @return
	 */
	public int deleteUser(String name);
}



