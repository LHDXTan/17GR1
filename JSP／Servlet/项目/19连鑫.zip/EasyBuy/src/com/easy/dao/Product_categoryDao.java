package com.easy.dao;

import java.util.List;

import com.easy.entity.Product;
import com.easy.entity.Product_category;

/**
 * 商品分类的方法
 * @author Administrator
 *
 */
public interface Product_categoryDao {
	/**
	 * 获取三级菜单
	 * @return
	 */
	public List<Product_category> getProduct3();
	/**
	 * 获取二级菜单
	 * @return
	 */
	public List<Product_category> getProduct2();
	/**
	 * 获取一级菜单
	 * @return
	 */
	public List<Product_category> getProduct1();
	/**
	 * 根据父ID获取所有子类商品分类
	 * @return
	 */
	public List<Product_category> getProductByID(Integer id);
}
