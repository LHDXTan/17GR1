package com.easy.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.easy.dao.BaseDao;
import com.easy.dao.Product_categoryDao;
import com.easy.entity.Product;
import com.easy.entity.Product_category;

public class Product_categoryDaoImpl extends BaseDao implements Product_categoryDao{

	@Override
	public List<Product_category> getProduct3() {
		// TODO Auto-generated method stub
		List<Product_category> list3 = new ArrayList<Product_category>();
		ResultSet rs = null;
		Product_category pc = null;
		String sql = "select * from easybuy_product_category where type = 3 ";
		try {
			rs=this.executeQuery(sql);
			while(rs.next()){
				pc = new Product_category();
				pc.setId(rs.getInt("id"));
				pc.setName(rs.getString("name"));
				pc.setParentId(rs.getInt("parentId"));
				pc.setType(rs.getInt("type"));
				list3.add(pc);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			closeAll(conn, null, rs);
		}
		return list3;
	}

	@Override
	public List<Product_category> getProduct2() {
		// TODO Auto-generated method stub
		List<Product_category> list2 = new ArrayList<Product_category>();
		ResultSet rs = null;
		Product_category pc = null;
		String sql = "select * from easybuy_product_category where type = 2 ";
		try {
			rs=this.executeQuery(sql);
			while(rs.next()){
				pc = new Product_category();
				pc.setId(rs.getInt("id"));
				pc.setName(rs.getString("name"));
				pc.setParentId(rs.getInt("parentId"));
				pc.setType(rs.getInt("type"));
				list2.add(pc);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			closeAll(conn, null, rs);
		}
		return list2;
	}

	@Override
	public List<Product_category> getProduct1() {
		// TODO Auto-generated method stub
		List<Product_category> list1 = new ArrayList<Product_category>();
		ResultSet rs = null;
		Product_category pc = null;
		String sql = "select * from easybuy_product_category where type = 1 ";
		try {
			rs=this.executeQuery(sql);
			while(rs.next()){
				pc = new Product_category();
				pc.setId(rs.getInt("id"));
				pc.setName(rs.getString("name"));
				pc.setParentId(rs.getInt("parentId"));
				pc.setType(rs.getInt("type"));
				list1.add(pc);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			closeAll(conn, null, rs);
		}
		return list1;
	}

	@Override
	public List<Product_category> getProductByID(Integer id) {
		// TODO Auto-generated method stub
		List<Product_category> list = new ArrayList<Product_category>();
		ResultSet rs = null;
		Product_category pc = null;
		String	sql;
		Object[]obj={id};
		if(id == null){
			sql="select * from easybuy_product_category where parentId=0";
			rs=this.executeQuery(sql);
		}else{
			sql="select * from easybuy_product_category where parentId=?";
			rs=this.executeQuery(sql, obj);
		}
		
		try {
			while(rs.next()){
				pc =  new Product_category();
				pc.setId(rs.getInt("id"));
				pc.setName(rs.getString("name"));
				pc.setParentId(rs.getInt("parentId"));
				pc.setType(rs.getInt("type"));
				list.add(pc);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			closeAll(conn, null, rs);
		}
		return list;
	}

}
//p = new Product();
//p.setId(rs.getInt("id"));
//p.setName(rs.getString("name"));
//p.setDescription(rs.getString("description"));
//p.setPrice(rs.getFloat("price"));
//p.setStock(rs.getInt("stock"));
//p.setCategoryLevel1(rs.getInt("categoryLevel1"));
//p.setCategoryLevel2(rs.getInt("categoryLevel2"));
//p.setCategoryLevel3(rs.getString("categoryLevel3"));
//p.setFileName(rs.getString("fileName"));
//p.setIsDelete(rs.getShort("isDelete"));