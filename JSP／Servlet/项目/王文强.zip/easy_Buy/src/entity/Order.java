package entity;

import java.util.Date;

/**
 * 订单：存放订单相关信息
 * @author lenovo
 *
 */
public class Order {
		private int id;//���
		private String userId;//用户ID
		private String loginName;//用户名
		private String userAddress;//用户地址ַ
		private Date createTime;//创建时间
		private float cost;//金额
		private int status;//状态״
		private int type;//类型
		private String serialNumber;//订单号
		public Order() {
			super();
			// TODO Auto-generated constructor stub
		}
		public Order(int id, String userId, String loginName,
				String userAddress, Date createTime, float cost, int status,
				int type, String serialNumber) {
			super();
			this.id = id;
			this.userId = userId;
			this.loginName = loginName;
			this.userAddress = userAddress;
			this.createTime = createTime;
			this.cost = cost;
			this.status = status;
			this.type = type;
			this.serialNumber = serialNumber;
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getUserId() {
			return userId;
		}
		public void setUserId(String userId) {
			this.userId = userId;
		}
		public String getLoginName() {
			return loginName;
		}
		public void setLoginName(String loginName) {
			this.loginName = loginName;
		}
		public String getUserAddress() {
			return userAddress;
		}
		public void setUserAddress(String userAddress) {
			this.userAddress = userAddress;
		}
		public Date getCreateTime() {
			return createTime;
		}
		public void setCreateTime(Date createTime) {
			this.createTime = createTime;
		}
		public float getCost() {
			return cost;
		}
		public void setCost(float cost) {
			this.cost = cost;
		}
		public int getStatus() {
			return status;
		}
		public void setStatus(int status) {
			this.status = status;
		}
		public int getType() {
			return type;
		}
		public void setType(int type) {
			this.type = type;
		}
		public String getSerialNumber() {
			return serialNumber;
		}
		public void setSerialNumber(String serialNumber) {
			this.serialNumber = serialNumber;
		}
		
		
}
