package entity;

import com.danga.MemCached.MemCachedClient;
import com.danga.MemCached.SockIOPool;

public class test {
	public static void main(String[] args) {
        String[] servers = { "192.168.1.126:11211" };  //配置服务端的地址，看好这是个数组，也意味着多个服务端地址直接扔到数组里即可
        //得到一个链接池对象并进行一些初始化工作
        SockIOPool pool = SockIOPool.getInstance();
        pool.setServers(servers);//设置服务端
        pool.setFailover(true);     //大概意思是为false如果连接管道失败了直接返回就不会再去找其他机器了，为true会组装一些新的key到剩下的服务器里去找。
        pool.setInitConn(10);     //初始化时对每个服务器建立的连接数目
        pool.setMinConn(5);         //每个服务器建立最小的连接数，当自查线程发现与某个服务器建立连接数目小于这个数目时会弥补剩下的连接
        pool.setMaxConn(250);     //每个服务器建立最大的连接数
        //pool.setMaintSleep( 30 );//自查线程周期进行工作，其每次休眠时间
        pool.setNagle(false);     //Socket的参数，如果是true在写数据时不缓冲，立即发送出去 
        pool.setSocketTO(3000);  //Socket阻塞读取数据的超时时间 
        pool.setAliveCheck(true);//为true会检查Socket是否已经连接
        pool.initialize();         //初始化完毕
        //得到具体的客户端操作对象
        MemCachedClient mcc =new MemCachedClient();
         User user = new User();
        //插入数据3中方式
        mcc.set("test1", "测试1");//第一种，这种方式如果key已存在则直接覆盖重写了
        mcc.add("test2", "测试2");//第二种，这种方式只会添加，如果key已存在则返回false，添加不成功
        mcc.replace("test3", "测试3");//顾名思义，同第一种差不多。
        //如果想要存实体类，必须要将实体类序列化。让实体类 去  implements Serializable  这个接口
        //如果想要存泛型集合，同理，对应的泛型也必须要序列化。
        //获取数据
        mcc.get("test1");//获取到的数据别忘啦转型哦
        //删除数据
//        mcc.delete("test1");
        //清空数据
//        mcc.flushAll();//执行了此方法，所有缓存的数据都置空了，再获取则为null
        
    }
}
