package dao;

import java.util.List;

import entity.ProductCategory;

public class ProductCategoryVo {

public void setProductCategory(ProductCategory product1Category) {
	
}


	
}
