package dao;

import java.util.List;

import entity.ProductCategory;


public interface ProductCategoryDao {
	
	/**
	 * 根据ID查询商品分类
	 */
	public ProductCategory getById(Integer id);
	/**
	 * 查询商品分类列表
	 */
	public List<ProductCategory> queryProductCategoryList();
	/**
	 * 查询商品分类列表数量
	 */
	public int queryProductCategoryCount(int id);
	/**
	 * 修改商品分类
	 */
	public int modifyProductCategory(ProductCategory productcategory);
	/**
	 * 添加商品分类
	 */
	public int addProductCategory(ProductCategory productcategory);
	/**
	 * 根据id删除商品
	 */
	public int deleteById(Integer id);
	/**
	 * 根据父ID查询所有子分类
	 */
	public List<ProductCategory> getProductCategories(Integer parentId);
	/**
	 * 查询全部的商品分类
	 */
	public List<ProductCategoryVo> queryAllProductCategoryList();
}
