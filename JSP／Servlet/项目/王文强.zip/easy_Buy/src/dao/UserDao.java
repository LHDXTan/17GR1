package dao;

import java.util.List;

import entity.User;

public interface UserDao {
	/**
	 * 添加用户
	 * @param user
	 * @return
	 */
	public int addUser(User user);	
	/**
	 * 判断用户是否登录成功 
	 * @param loginName
	 * @param password
	 * @return
	 */
	public User findUser(String loginName,String password);
	/**
	 * 查找用户
	 * @return
	 */
	public List<User> getUser();
}
