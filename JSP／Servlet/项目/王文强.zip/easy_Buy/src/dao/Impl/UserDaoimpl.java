package dao.Impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.BaseDao;
import dao.UserDao;
import entity.User;

public class UserDaoimpl extends BaseDao implements UserDao{

	
	/**
	 * 添加用户
	 */
	public int addUser(User user) {
		String sql = "insert into easybuy_user(loginName,userName,password,sex,identityCode,email,mobile,type) values(?,?,?,?,?,?,?,?)";
		return executeUpdate(sql, new Object[]{user.getLoginName(),user.getUserName(),user.getPassword(),user.getSex(),user.getIdentityCode(),user.getEmail(),user.getMobile(),user.getType()});
	}
//	String sql = "insert into easybuy_user(loginName,userName,password,sex) values(?,?,?,?)";
//	return executeUpdate(sql, new Object[]{user.getLoginName(),user.getUserName(),user.getPassword(),user.getSex()});

	@Override
//	/**
//	 * 判断用户是否登录成功
//	 */
//	public User findUser(String loginName ,String password) {
//		String sql= "select loginName,password from easybuy_user";
//		ResultSet rs = this.executeQuery(sql, loginName,password);
//		User user = null;
//		try {
//			while(rs.next()){
//				 user = new User();
//				user.setLoginName(loginName);
//				user.setPassword(password);
//			}
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		return user;
//	}
	public User findUser(String loginName ,String password) {
		String sql = "select * from easybuy_user where loginName = ? and password = ?";
			ResultSet rs = super.executeQuery(sql,loginName,password);
			User user = null;
			try {
				while(rs.next()){
					user = new User();
					user.setLoginName(loginName);
					user.setPassword(password);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return user;
	}
	@Override
	public List<User> getUser() {
		String sql ="select * from easybuy_user";
		ResultSet rs = this.executeQuery(sql);
		List<User> list = new ArrayList<User>();
		try {
			while(rs.next()){
				int id = rs.getInt("id");
				String loginName = rs.getString("loginName");
				String userName = rs.getString("userName");
				String password = rs.getString("password");
				String sex = rs.getString("sex");
				String identityCode = rs.getString("identityCode");
				String email = rs.getString("email");
				String mobile = rs.getString("mobile");
				int type = rs.getInt("type");
				User user2 = new User(id, loginName, userName, password, sex, identityCode, email, mobile, type);
				list.add(user2);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
}
