package com.Empity;

import java.sql.Connection;

import com.Dao.BaseDao;

public class User extends BaseDao{
	Connection conn = BaseDao.getCon();
}
