﻿package test;

import java.util.List;
import java.util.Scanner;


import dao.PetDao;
import dao.PetOwnerDao;
import dao.PetStoreDao;
import dao.impl.PetDaoImpl;
import dao.impl.PetOwnerDaoImpl;
import dao.impl.PetStoreDaoImpl;
import entity.Pet;
import entity.PetOwner;
import entity.PetStore;

public class Main {

	public static void main(String[] args) {
		Main.startPetShop();
	}

	private static void startPetShop() {
		System.out.println("宠物商店启动");
		System.out.println("Wonderland醒来,所有宠物从MySQL中醒来");
		PetDao petDao = new PetDaoImpl();
		List<Pet> petList = petDao.getAllPet();
		System.out.println("序号\t" + "宠物名称\t");
		for (int i = 0; i < petList.size(); i++) {
			Pet pet = petList.get(i);
			System.out.println((i + 1) + "\t" + pet.getName() + "\t");
		}
		System.out.print("\n");
		System.out.println("所有宠物主人从MySQL中醒来");
		PetOwnerDao ownerDao = new PetOwnerDaoImpl();
		List<PetOwner> ownerList = ownerDao.getAllOwner();
		System.out.println("序号\t" + "主人姓名\t");
		for (int i = 0; i < ownerList.size(); i++) {
			PetOwner owner = ownerList.get(i);
			System.out.println((i + 1) + "\t" + owner.getName() + "\t");
		}
		System.out.print("\n");
		System.out.println("所有宠物商店从MySQL中醒来");
		PetStoreDao storeDao = new PetStoreDaoImpl();
		List<PetStore> storeList = storeDao.getAllStore();
		System.out.println("序号\t" + "宠物商店名称\t");
		for (int i = 0; i < storeList.size(); i++) {
			PetStore store = storeList.get(i);
			System.out.println((i + 1) + "\t" + store.getName() + "\t");
		}
		System.out.print("\n");
		Scanner input = new Scanner(System.in);
		// 选择登录方式
		System.out.println("请选择输入登录模式:1.宠物主人登录   2.宠物商店登录");
		boolean type = true;
		String num;
		while (type) {
			num = input.next();
			if (num.equals("1")) {
				Main.ownerLogin();
				type = false;
			} else if (num.equals("2")) {
				Main.storeLogin();
				type = false;
			} else {
				System.out.println("输入有误，请按照指定规则输入");
			}
		}
	}

	// 宠物主人登录
	private static void ownerLogin() {
		Scanner input = new Scanner(System.in);
		PetOwnerDaoImpl petOwner = new PetOwnerDaoImpl();
		PetOwner Owner = petOwner.login();
		boolean bl = true;
		while (bl) {
			if (null == Owner) {
				System.out.println("登录失败，请确认您的用户名和密码后重新输入");
				Owner = petOwner.login();
				bl = true;
			} else {
				bl = false;
				System.out.println("登录成功");
				System.out.println("请选择:1.购买宠物   2.卖出宠物");
				boolean type = true;
				while (type) {
					int num = input.nextInt();
					if (1 == num) {

						Main.ownerBuy(Owner);
						type = false;
					} else if (2 == num) {
						Main.ownerSell(Owner);
						type = false;
					} else {
						System.out.println("输入有误,请重新输入");
						type = true;
					}
				}
			}
		}

	}

	private static void storeLogin() {
		Scanner input = new Scanner(System.in);
		PetStore petStore = new PetStore();
		PetStore store = petStore.login();
		System.out.println("登录成功");
		System.out.println("请选择功能:1.购买宠物 2.卖出宠物 3.培育宠物 4.查询待售宠物 5.查看商店结余 6.查看商店账目 7.开宠物商店");

		while (true) {
			int num = input.nextInt();
			switch (num) {
			case 1:
				Main.storeBuy(store);
				break;
			case 2:
				Main.storeSell(store);
				break;
			case 3:
				Main.storeBread();
				break;
			case 4:
				Main.queryPetStock(store.getId());
				break;
			case 5:
				Main.queryStoreBalance(store);
				break;
			case 6:
				Main.getAccount(store.getId());
				break;
			case 7:
				Main.createPetStore();
				break;
			default:
				System.out.println("输入有误,请重新输入");
				
			}
		}
	}


	/**
	 * 查询商店结余
	 */
	private static void queryStoreBalance(PetStore store) {

		double balance = store.getBalance();
		System.out.println(store.getName() + "宠物商店的结余为:" + balance);
	}

	private static void queryPetStock(long id) {
		
	}
	/**
	 * 查询待售宠物
	 * 
	 * @param storeId
	 */
	private static void queryPetStock(long id, Object storeId) {
		PetStore petStore = new PetStore();
		Pet pet = null;
		List<Pet> petList = petStore.getPetsInstock(storeId);
		System.out.println("序号\t" + "宠物名称\t" + " 类型\t");
		for (int i = 0; i < petList.size(); i++) {
			pet = petList.get(i);
			System.out.println((i + 1) + "\t" + pet.getName() + "\t" + pet.getTypename() + "\t");
		}
	}

	private static void createPetStore() {
	

	}

	private static void getAccount(long id) {
					
	}

	private static void storeBread() {
		
	}

	private static void storeSell(PetStore store) {
		

	}

	/**
	 * 宠物商店购买宠物
	 */
	private static void storeBuy(PetStore store) {		
		Scanner input = new Scanner(System.in);
		PetStore petStore = new PetStore();
		Pet pet = null;
		List<Pet> petList = petStore.getPetSelling();
		System.out.println("-------以下是宠物主人正在出售的宠物-------");
		System.out.println("序号\t" + "宠物名称\t" + " 类型\t" + "\t元宝数\t");
		for (int i = 0; i < petList.size(); i++) {
			pet = petList.get(i);
			double price = petStore.charge(pet);// 获得到宠物的价格
			System.out.println((i + 1) + "\t" + pet.getName() + "\t" + pet.getTypename() + "\t" + price + "\t");
		}
		System.out.println("-------请选择要购买哪个一个宠物，并输入选择项的序号-------");
		int num = input.nextInt();
		pet = petList.get(num - 1);
		petStore.buy(pet);

	}

	private static void ownerSell(PetOwner owner) {

	}

	private static void ownerBuy(PetOwner owner) {

	}

}
