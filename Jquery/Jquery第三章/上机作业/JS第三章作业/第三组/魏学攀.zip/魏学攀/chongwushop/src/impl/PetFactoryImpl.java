
package service.impl;

import entity.Pet;
import service.PetFactory;

/**
 * ���﹤��ʵ����
 */
public class PetFactoryImpl implements PetFactory {
	/**
	 * ���﹤��������Ʒ�ֳ���
	 */
	public Pet breadNewPet(String[] petParam) {
		Pet pet = new Pet();
		pet.setName(petParam[0]);
		pet.setTypename(petParam[1]);
		pet.setHealth(Integer.parseInt(petParam[2]));
		pet.setLove(Integer.parseInt(petParam[3]));
		pet.setStoreid(Integer.parseInt(petParam[4]));
		return pet;
	}
}
