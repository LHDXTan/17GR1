package entity;

import java.util.List;

public class PetStore {
	private long id;
	private String name;
	private String password;
	private double balance;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}

	public List<Pet> getPetsInstock(Object storeId) {
		// TODO Auto-generated method stub
		return null;
	}
	public PetStore login() {
		// TODO Auto-generated method stub
		return null;
	}
	public List<Pet> getPetSelling() {
		// TODO Auto-generated method stub
		return null;
	}
	public double charge(Pet pet) {
		// TODO Auto-generated method stub
		return 0;
	}
	public void buy(Pet pet) {
		// TODO Auto-generated method stub
		
	}
	
	

}
