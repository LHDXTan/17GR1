package dao;

import java.util.List;

import entity.PetStore;


public interface PetStoreDao {
	public abstract List<PetStore> getAllStore();
	 //根据查询条件查询出宠物商店 
	public abstract PetStore getPetStore(String sql, String[] param);
	 // 更新宠物商店信息 
	public abstract int updateStore(String sql, Object[] param);


}
