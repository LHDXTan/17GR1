package entity;

import java.util.Date;

public class Account {
	private long id;
	private int dealtype;
	private long petid;
	private long sellerid;
	private long buyerIdid;
	private double peice;
	private Date dealtime;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public int getDealtype() {
		return dealtype;
	}
	public void setDealtype(int dealtype) {
		this.dealtype = dealtype;
	}
	public long getPetid() {
		return petid;
	}
	public void setPetid(long petid) {
		this.petid = petid;
	}
	public long getSellerid() {
		return sellerid;
	}
	public void setSellerid(long sellerid) {
		this.sellerid = sellerid;
	}
	public long getBuyerIdid() {
		return buyerIdid;
	}
	public void setBuyerIdid(long buyerIdid) {
		this.buyerIdid = buyerIdid;
	}
	public double getPeice() {
		return peice;
	}
	public void setPeice(double peice) {
		this.peice = peice;
	}
	public Date getDealtime() {
		return dealtime;
	}
	public void setDealtime(Date dealtime) {
		this.dealtime = dealtime;
	}
	
	

}
