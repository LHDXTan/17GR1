$(document).ready(function () {
	$("dt").click(function () {
		$("dd span[id]").css({"color":"#ff0099","font-weight":"bold"});
	})
	$("#director").click(function () {
		$("#director+span").css("font-weight","bold");
	})
	$("#label").click(function () {
		$("#label~span").css({"background":"#e0f8ea","color":"#10A14B","padding":"2px 8px"});
	})
	$("br+img").click(function () {
		alert("您已收藏成功！");
	})
})