$(document).ready(function () {
	$("p").click(function () {
		$(".txt_box .current").css("background","#6ff");
		$("p span").css("background","#f9f");
		$("h1+p").css("background","#ff6");
		$("#content span span").css({"color":"#fff","background":"#f00"});
	})
})