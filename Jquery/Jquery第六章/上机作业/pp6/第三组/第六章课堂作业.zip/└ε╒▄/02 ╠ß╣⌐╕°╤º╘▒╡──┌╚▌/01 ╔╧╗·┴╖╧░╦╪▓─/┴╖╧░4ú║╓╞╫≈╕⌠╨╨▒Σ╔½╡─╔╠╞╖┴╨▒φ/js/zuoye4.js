$(document).ready((function() {
	$(".contain tr:not(.t-head):even").css("background", "#eff7d1");
	$(".contain tr:not(.t-head):odd").css("background", "#f7e195");
})())