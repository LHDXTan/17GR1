$(document).ready(function () {
	$(".intro").css("color","red");
	$("#jdPrice>span").css({"font-size":"24px","color":"red","font-weight":"bold"});
	$("#jdPrice>p").css("color","#cccccc");
	$("#jdPrice>p span").css("text-decoration","line-through");
	$("dl").css("color","red");
	$("dt").click(function () {
		$("dd").css("display","block");
	})
	$("dl span,#ticket span").css({
		"background":"#ff0000","color":"#ffffff","padding":"1px 5px","margin-right":"5px"});
})

