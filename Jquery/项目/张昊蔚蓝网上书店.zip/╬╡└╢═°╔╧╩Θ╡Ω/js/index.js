$(function(){
//	打开页面时弹出广告窗口
	/*function open(){
	window.open("open.html","","width=600,height=400")
	}
	open();*/
//	下拉菜单自动显示与隐藏
	$("#menu").hover(function(){
		$("#dd_menu_top_down").show()
	},function(){
	$("#dd_menu_top_down").hide();
	})
//	随滚动条滚动可关闭广告
 	$(window).scroll(function(){
        var st = $(this).scrollTop()+50;
        $("#right").css("top",st);
    });
	$("#dd_close").click(function(){
		document.getElementById("right").style.display="none";
	})
//	带数字按钮的循环显示

//	书讯快递无缝隙,循环垂直向上滚动
	
//	电子书特效
	$(".book ul img").hover(function(){
		$(this).animate({width:"110%"},"slow")
	},function(){
		$(this).animate({width:"80%"},"slow")
	})
//	Tab切换
//	$(".tab p").mouseover(function(){
//		$(".tab dl").show()
//	})
	$(".tab ul li p").mouseenter(function(){
		$(this).hide();
		$(this).next().show()
		$(this).parent().siblings().children("p").show().end().children("dl").hide();
	})
	$(".tab ol li:eq(0)").mouseover(function(){
		$(this).css("background","#efefef")
		$(".tab ul:eq(0)").show()
		$(".tab ul:eq(1)").hide()
	})
	
	$(".tab ol li:eq(1)").hover(function(){
		$(this).css({"background":"#ffffff","border-bottom",})
		$(".tab ul:eq(1)").show()
		$(".tab ul:eq(0)").hide()
	},function(){
		
	})
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
})
