$(function(){
$("#email").focus(function(){
	$(this).removeClass().addClass("login_content_input_Focus")
}).blur(function(){
	$(this).removeClass().addClass("login_content_input")
})

$("#pwd").focus(function(){
	$(this).removeClass().addClass("login_content_input_Focus")
}).blur(function(){
	$(this).removeClass().addClass("login_content_input")
})
	
	$("#loginForm").submit(function(){
		var mail= $("#email").val()
	var pw = $("#pwd").val()
		if (mail=="") {
			alert("请输入email地址或昵称")
			return false;
		}
//		if(reg.test(mail)==false){
//						alert("格式不正确,xxx@xx.com")
//						return false;
//					}
//					$("#email").html("")
//					return true;
		if(pw==""){
			alert("请输入密码")
			return false;
		}
		return true;
	})
})
