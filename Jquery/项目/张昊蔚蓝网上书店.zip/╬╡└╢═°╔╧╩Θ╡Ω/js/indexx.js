$(function() {
		//打开页面时弹出广告窗口
	function open(){
	window.open("open.html","","width=600,height=400")
	}
	open();
	//	下拉菜单自动显示与隐藏
	$("#menu").hover(function() {
		$("#dd_menu_top_down").show()
	}, function() {
		$("#dd_menu_top_down").hide();
	})

	//	随滚动条滚动可关闭广告
	$(window).scroll(function() {
		var st = $(this).scrollTop() + 50;
		$("#right").css("top", st);
	});
	$("#dd_close").click(function() {
		document.getElementById("right").style.display = "none";
	})
	//书讯快递
	function movedome() {
		var marginTop = 0;
		var stop = false;
		var interval = setInterval(function() {
			if(stop) return;
			$("#express").children("li").first().animate({
				"margin-top": marginTop--
			},0, function() {
				var $first = $(this);
				if(!$first.is(":animated")) {
					if((-marginTop) > $first.height()) {
						$first.css({
							"margin-top": 0
						}).appendTo($("#express"));
						marginTop = 0;
					}
				}
			});
		}, 50);
		$("#express").mouseover(function() {
			stop = true;
		}).mouseout(function() {
			stop = false;
		});
	}
	movedome();
	//	电子书特效
	$(".book ul img").hover(function() {
		$(this).animate({
			width: "110%"
		}, "slow")
	}, function() {
		$(this).animate({
			width: "80%"
		}, "slow")
	})
//	畅销榜切换
	$(".tab ul li p").mouseenter(function() {
		$(this).hide();
		$(this).next().show()
		$(this).parent().siblings().children("p").show().end().children("dl").hide();
//		回到最近的一个"破坏性"操作之前。即，将匹配的元素列表变为前一次的状态。
	})
	$(".tab ol li:eq(0)").mouseover(function() {
		$(this).css({
			"background": "#ffffff",
			"border": "none"
		});
		$(".tab ol li:eq(1)").css({
			"background": "#efefef",
			"border-bottom": "1px solid #ccc"
		})
		$(".tab ul:eq(0)").show()
		$(".tab ul:eq(1)").hide()
	})
	$(".tab ol li:eq(1)").mouseover(function() {

		$(this).css({
			"background": "#ffffff",
			"border-bottom": "none"
		})
		$(".tab ol li:eq(0)").css({
			"background": "#efefef",
			"border-bottom": "1px solid #ccc"
		})
		$(".tab ul:eq(1)").show()
		$(".tab ul:eq(0)").hide()
	})

//轮播
 function changeImg(){
        var index=0;
        var stop=false;
        var $li=$("#content").find("#scroll_img").children("li");
        var $page = $("#content").find("#scroll_number").children("li");
        $page.eq(index).addClass("scroll_number_over").stop(true,true).siblings().removeClass("scroll_number_over");
        $page.mouseover(function(){
            stop=true;
            index=$page.index($(this));
            $li.eq(index).stop(true,true).fadeIn().siblings().fadeOut();
            $(this).addClass("scroll_number_over").stop(true,true).siblings().removeClass("scroll_number_over");
        }).mouseout(function(){
            stop=false;
        });
        setInterval(function(){
            if(stop) return;
            index++;
            if(index>=$li.length){
                index=0;
            }
            $li.eq(index).stop(true,true).fadeIn().siblings().fadeOut();
            $page.eq(index).addClass("scroll_number_over").stop(true,true).siblings().removeClass("scroll_number_over");
        },3000);
    }
    changeImg();

})