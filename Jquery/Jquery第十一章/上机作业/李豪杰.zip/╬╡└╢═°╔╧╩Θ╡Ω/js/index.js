$(function(){
	//打开一个广告窗口
	window.open('open.html','','width=500,height=400')
	
	//随滚动条滚动的可以关闭的广告
	
	$(window).scroll(function(){
		var st = $(this).scrollTop()+50;
		$("#right").css("top",st);
	});
	$("#right").find("a").click(function(){
	    $("#right").hide();	
	});
	//轮播图
	function lubo(){
		var stop=false;
		$("#scroll_number li").hover(function(){
			stop=true;
			$(this).removeClass().addClass("scroll_number_over");
			$(this).siblings().removeClass("scroll_number_over");
			var a=$(this).text();
			$("#scroll_img li:eq("+(a-1)+")").fadeIn().show();
			$("#scroll_img li:eq("+(a-1)+")").siblings().fadeOut().hide();
			
		},function(){
			stop=false; 
			
		})
		var i=1;
		$(setInterval(function(){
			if(stop==true){
				return false;
				
			}
			if(i==1){
				$("#scroll_number li").not("#scroll_number li:eq(0)").removeClass("scroll_number_over");
				$("#scroll_number li:eq(0)").addClass("scroll_number_over");
				
			}
			if(i==4){
				i=0;
			}
			$("#scroll_number li").not("#scroll_number li:eq("+i+")").removeClass("scroll_number_over");
			$("#scroll_img li:eq("+i+")").show();
			$("#scroll_img li").not("#scroll_img li:eq("+i+")").hide();
			$("#scroll_number li:eq("+i+")").addClass("scroll_number_over");
			i++;
		},1000))
		
	}
	lubo();
	
	//书讯快递循环向上移动
	function gun(){
		var marginTop=0;
		var stop=false;
		var interval=setInterval(function(){
			if(stop)return;
			$("#express").children("li").first().animate({"margin-top":marginTop--},0,function(){
				var $first=$(this);
				if(!$first.is(":animated")){
					if((-marginTop)>$first.height()){
						$first.css({"margin-top":0}).appendTo($("#express"));
						marginTop=0;
					}
				}
			});
		},50);
		$("#express").mouseover(function(){
			stop=true;
		}).mouseout(function(){
			stop=false;
		});
	}
//	gun();
	//图片的变换
	$(".book ul img").mouseenter(function(){
		$(this).animate({width:"113%"},"slow");
	});
	
	$(".book ul img").mouseleave(function(){
		$(this).animate({width:"83%"},"slow");
	});
	
	图书畅销榜切换
	$(".tab ol li:first-of-type").mouseover(function(){
        $(".tab ol li:last-of-type").css({"background":"#efefef","border-left":"1px solid #cccccc","border-bottom":"1px solid #ccc","width":"118px"});
        $(this).css({"width":"119px","background":"#ffffff","border":"none"});
        $(".tab ul:first-of-type").show();
        $(".tab ul:last-of-type").hide();
    });
	$(".tab ol li:last-of-type").mouseover(function(){
		 $(".tab ol li:first-of-type").css({"background":"#efefef","border-left":"1px solid #cccccc","border-bottom":"1px solid #ccc","width":"118px"});
		$(this).css({"width":"119px","background":"#ffffff","border":"none"});
		$(".tab ul:first-of-type").hide();
		$(".tab ul:last-of-type").show();
		
	});
	 $(".tab ul li p").mouseenter(function(){
        $(this).next().show();
        $(this).hide();
        $(this).parent().siblings().children("p").show().end().children("dl").hide();
   });
	
	
})




